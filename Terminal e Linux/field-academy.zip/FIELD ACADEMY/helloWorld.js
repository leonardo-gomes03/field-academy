function helloWorld(){
	console.log( "Hello Field Academy!")
}

helloWorld();
